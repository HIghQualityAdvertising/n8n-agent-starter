import { IExecuteFunctions } from 'n8n-workflow';
import { INodeType, INodeTypeDescription } from 'n8n-workflow';

export class ComposeSPINMessage implements INodeType {
	description: INodeTypeDescription = {
		displayName: 'Compose SPIN Message',
		name: 'composeSPINMessage',
		group: ['transform'],
		version: 1,
		description: 'Composes a personalized SPIN sales message based on lead data',
		defaults: {
			name: 'Compose SPIN Message',
		},
		inputs: ['main'],
		outputs: ['main'],
		properties: [
			{
				displayName: 'Lead JSON',
				name: 'lead',
				type: 'json',
				default: '',
				description: 'Lead data to generate SPIN message',
			},
		],
	};

	async execute(this: IExecuteFunctions) {
		const items = this.getInputData();
		const returnData = [];

		for (let i = 0; i < items.length; i++) {
			const lead = this.getNodeParameter('lead', i) as {
				name: string;
				company: string;
				issue: string;
				impact: string;
			};

			const message = `
Hi ${lead.name},

I've been looking at ${lead.company} and noticed you might be facing: ${lead.issue}. 
This can lead to: ${lead.impact}.

Would you be open to a quick chat on how we’ve helped similar teams?

Best,  
[Your Name]
			`.trim();

			returnData.push({ json: { message } });
		}

		return this.prepareOutputData(returnData);
	}
}
