import { IExecuteFunctions } from 'n8n-workflow';
import { INodeType, INodeTypeDescription } from 'n8n-workflow';

export class RetryHandler implements INodeType {
	description: INodeTypeDescription = {
		displayName: 'Retry Handler',
		name: 'retryHandler',
		group: ['transform'],
		version: 1,
		description: 'Retries failed requests up to 3 times',
		defaults: {
			name: 'Retry Handler',
		},
		inputs: ['main'],
		outputs: ['main'],
		properties: [],
	};

	async execute(this: IExecuteFunctions) {
		const items = this.getInputData();
		const returnData = [];

		for (let i = 0; i < items.length; i++) {
			let attempt = 0;
			let success = false;
			let result;

			while (attempt < 3 && !success) {
				try {
					result = items[i].json;
					success = true;
				} catch (error) {
					attempt++;
					if (attempt === 3) {
						result = { error: error.message };
					}
				}
			}

			returnData.push({ json: result });
		}

		return this.prepareOutputData(returnData);
	}
}
